---
description: Scaffold nowego typu lub wariantu sekcji wg standardu A9.1–A9.3
argument-hint: <typ> <wariant>
---
Tworzymy sekcję wg argumentów: `$ARGUMENTS` (pierwszy = typ, np. `menu`; drugi = wariant, np. `board-chalk`).

Zanim zaczniesz: przeczytaj w VORTBUILD_MEGA_PROMPT.md sekcje A8.4 (koperta sekcji), A9.1 (definicja w rejestrze), A9.2 (katalog) i A9.3 (standard jakości) oraz docs/SITE_SCHEMA.md. Sprawdź w `packages/sections/src/registry.ts`, czy typ już istnieje — jeśli tak, dodajesz tylko wariant.

1. **Schemat** — `packages/site-schema/src/sections/<typ>.ts`: propsy z `.max()` na każdym polu tekstowym, `NeedsInput` tam, gdzie AI może nie znać faktu, `sectionEnvelope('<typ>', Props, [warianty])`, dopisanie do unii `Section` w `document.ts`.
   - Nowy typ albo zmiana kształtu danych = podbicie `schemaVersion` + migracja w `migrate.ts` + test migracji.
   - Nowy wariant istniejącego typu = tylko rozszerzenie listy wariantów (bez migracji).
2. **Komponent** — jeden plik na wariant w `packages/sections/src/<typ>/`: czysty komponent serwerowy (bez hooków), prymitywy z `primitives/`, kolory tylko przez zmienne motywu, klasy Tailwind statyczne (mapy obiektów), interakcje wyłącznie `data-vb-*` + `runtime/site-runtime.ts`.
3. **Rejestr** — definicja wg `SectionDefinition`: etykieta PL, kategoria, `imageSlots` (rola, proporcje, `minWidth`, `overlayText`), `bestFor`, `styleTags`, `itemLimits`, `defaults()`, metadane pól edytora (etykiety PL, kontrolki, grupy, podpowiedzi), `ai.purpose`, `ai.copyRules`, `ai.example` (wzorcowe polskie wypełnienie dla fikcyjnej firmy, bez fraz z E2).
4. **Galeria dev** — wariant widoczny w `/dev/sekcje` z treścią minimalną, typową i maksymalną w 3 motywach.
5. **Testy** — `ai.example` i `defaults()` przechodzą walidację schematu; test DOM bez przepełnień w 390/768/1280/1920 px; zrzut Playwright do regresji wizualnej.
6. **Standard A9.3** — odhacz 10 punktów dla tej sekcji w docs/PROGRESS.md.
7. `pnpm catalogs`, potem `pnpm typecheck && pnpm lint && pnpm test`.

Na koniec pokaż: listę plików, zrzuty 390 i 1440 px oraz otwarte kwestie.
