# PRD — VORTBUILD (skrót)

> Streszczenie części A1–A3 z `VORTBUILD_MEGA_PROMPT.md`. Przy każdej rozbieżności wygrywa mega-prompt.

## Produkt w jednym zdaniu
AI kreator stron dla lokalnych biznesów w Polsce: właściciel opisuje lokal (do 1000 słów) albo przechodzi kreator krok po kroku, a po 2–3 minutach dostaje dopracowaną, gotową do publikacji stronę — dobrany szablon branżowy, teksty, zdjęcia, SEO lokalne, mapę, godziny otwarcia, menu lub cennik.

## Najważniejsza zasada jakości
AI **nie pisze HTML-a**. Strona jest składana z ręcznie zaprojektowanych, przetestowanych sekcji. AI **wybiera** szablon, **wypełnia** sekcje treścią, **dobiera** zdjęcia i **stroi** motyw — w ramach ścisłych schematów (ADR-001).

## Grupa docelowa (kolejność ważności)
1. Gastronomia — restauracje, pizzerie, kawiarnie, bistra, sushi, burgerownie, food trucki, cukiernie, piekarnie.
2. Beauty — barberzy, fryzjerzy, kosmetyczki, paznokcie, tatuaż, SPA.
3. Usługi lokalne — mechanicy, remonty, hydraulicy, elektrycy, sprzątanie, myjnie.
4. Zdrowie i ruch — fizjoterapia, gabinety, dentyści, siłownie, trenerzy, joga.
5. Noclegi i eventy — pensjonaty, apartamenty, sale weselne, fotografowie.
6. Freelancerzy i małe agencje robiące strony dla klientów (plan Max, white-label).

## Przewagi nad ogólnymi kreatorami AI (bolt.new, Lovable)
- Sekcje branżowe: menu z alergenami i oznaczeniami wege, cennik usług, zespół z linkami do Booksy, przed/po, godziny z plakietką „Otwarte teraz”, strefa dojazdu, linki do Pyszne/Glovo/Uber Eats.
- Polska treść jak od copywritera, bez banałów (zakazane frazy — załącznik E2).
- Zero wymyślonych faktów — braki oznaczane jako „Do uzupełnienia” (`NeedsInput`).
- Dobór zdjęć: wyszukiwanie + ocena wizualna przez model + spójność kolorystyczna.
- SEO lokalne od razu: `LocalBusiness` JSON-LD, mapa, sitemap, meta, Lighthouse ≥ 95.
- Edytor dla właściciela lokalu (kliknij tekst → zmień), nie dla programisty.

## Metryki sukcesu (North Star)
- % wygenerowanych stron, które zostają opublikowane lub wyeksportowane.
- Czas od rejestracji do pierwszej publikacji.
- Konwersja Free → Pro.
- Średnia ocena strony przez użytkownika (1–5 po generacji).

## Marka
- **Nazwa:** VORTBUILD (zawsze wielkimi literami) — *vortex* + *build*.
- **Logo:** sygnet z trzech łuków tworzących wir, które układają literę „V” + wordmark w Geist 700, tracking −0,02em. Wersje: pełna, sygnet (favicon), mono biała, mono czarna. SVG w kodzie.
- **Hasła:** „Opisz swój lokal. Resztę zbudujemy my.” · „Strona dla Twojego biznesu w 3 minuty.”
- **Ton:** na „Ty”, konkretny, pewny siebie, bez korpomowy, bez emoji w UI.
- **Domeny:** aplikacja `vortbuild.pl` lub `vortbuild.com`; strony klientów na osobnej `vortbuild.site` (ADR-005). Wszystkie domeny w env.

## Wygląd aplikacji
Dark-first, inspiracja bolt.new (ciemne tło, duże pole promptu na środku, poświata), ale z ciepłą „żarową” poświatą (gradient `#FF6B2C → #FF2D7A`, fioletowy wir `#7B61FF`). Fonty: Geist Sans, Geist Mono, Instrument Serif italic. Pełne tokeny: A2.2 i `.cursor/rules/50-app-ui.mdc`. Tryb jasny w etapie 13.

## Kluczowe przepływy użytkownika
1. **Landing → opis → rejestracja:** niezalogowany pisze opis i dodaje pliki; wysyłka otwiera rejestrację; szkic przeżywa (localStorage + IndexedDB) i czeka w `/nowa` po weryfikacji e-maila.
2. **Generacja (2–3 min, Ultra 3–5 min):** ekran w stylu bolt.new — oś kroków, dziennik na żywo, podgląd strony wypełniającej się na oczach użytkownika.
3. **Edytor:** ręczne zmiany bez limitu (klik w tekst, kolory, przeciąganie sekcji), czat AI do poprawek (limitowany), wersje, lista „Do uzupełnienia”.
4. **Publikacja / eksport / domena** wg planu: link podglądu (wszyscy), subdomena i ZIP (Pro), własna i kupiona domena, Next.js, white-label (Max).
5. **Brand Kit:** zapamiętane dane firmy do kolejnych stron (druga lokalizacja, promocja sezonowa).

## Landing `/` (12 sekcji — pełna treść w A2.3)
Pasek ogłoszeń · Nawigacja · Hero z polem promptu (licznik słów, chipy branż, „Ulepsz opis”, przełącznik „Opis swobodny | Kreator”) · Marquee wygenerowanych stron · Jak to działa · Co dostajesz · Branże · Porównanie (wartości szacunkowe do weryfikacji przez właściciela) · Cennik · FAQ · Końcowe CTA · Stopka.

## Plany (ceny brutto z VAT 23%)

| Funkcja | Free | Pro | Max |
|---|---|---|---|
| Cena miesięcznie | 0 zł | 80 zł (65,04 netto) | 150 zł (121,95 netto) |
| Cena rocznie (−20%) | — | 768 zł | 1440 zł |
| Generacje / okres | 5 | 40 | 120 |
| Poprawki AI / okres | 25 | 400 | 1500 (fair use) |
| Tryb Ultra | — | — | ✓ |
| Szablony | 12 bazowych, 1 paleta | wszystkie + palety + premium | jak Pro + nowe 14 dni wcześniej |
| Edycja ręczna | bez limitu | bez limitu | bez limitu |
| Link podglądu | 7 dni, znak wodny | bez znaku wodnego | bez znaku wodnego |
| Eksport ZIP | — | ✓ | ✓ |
| Eksport Next.js + GitHub | — | — | ✓ |
| Publikacja na subdomenie | — | do 3 stron | do 20 stron |
| Własna domena / zakup w panelu | — | — | ✓ / ✓ (+1 gratis w rocznym) |
| Plakietka „Zrobione w VORTBUILD” | — | tak | można wyłączyć |
| Zgłoszenia z formularzy / okres | — | 200 | 2000 |
| Analityka bez ciasteczek | — | 30 dni | 12 mies. + raport e-mail |
| Zdjęcia AI / okres | — | — | 60 |
| Miejsce na pliki | 200 MB | 2 GB | 20 GB |
| Historia wersji | 7 dni | 30 dni | bez limitu |
| Brand Kity | 1 | 3 | bez limitu |
| Strony wielojęzyczne | — | — | ✓ |
| Wsparcie | FAQ | e-mail 48 h | priorytet 12 h |
| Priorytet kolejki generacji | niski | normalny | wysoki |

Jedyne źródło cen i limitów w kodzie: `packages/billing/src/plans.ts` (struktura A3.3).

## Zasady rozliczeń (implementowane dokładnie tak)
- **Okres limitów:** Free — miesiąc kalendarzowy, reset 1. dnia o 00:00 `Europe/Warsaw`; Pro/Max — okres subskrypcji Stripe, reset przy `invoice.paid`.
- **Generacja** = jedno pełne wygenerowanie (nowy projekt albo „Wygeneruj od nowa”). Błąd po naszej stronie → automatyczny zwrot limitu.
- **Poprawka AI** = wiadomość w czacie, która wykonała zmiany. Pytanie doprecyzowujące od AI nie zużywa limitu.
- **Edycja ręczna** — zawsze bez limitu.
- **Free:** „Eksportuj” i „Opublikuj” widoczne z kłódką → modal porównania planów.
- **Downgrade Pro → Free:** opublikowane strony działają jeszcze 7 dni, potem są wyłączane (projekty zostają).
- **Downgrade Max → Pro:** domeny własne odłączane po 7 dniach; przy > 3 opublikowanych stronach użytkownik wybiera, które zostają.
- **Anulowanie:** działa do końca opłaconego okresu, potem zasady downgrade.
- **Koszt AI:** `koszt_generacji × średnie_zużycie ≤ 30% ceny netto planu` — mierzone w evals (etap 6) przed ogłoszeniem limitów.

## Sprawy formalne (decyduje właściciel / prawnik / księgowy)
Regulamin, polityka prywatności (RODO + lista podmiotów przetwarzających), cookies, zgoda na natychmiastowe rozpoczęcie usługi cyfrowej, DPA dla formularzy, informacja o treściach generowanych przez AI. Faktury VAT przez Fakturownia (KSeF). VAT w Stripe: Stripe Tax albo stała stawka.

## Poza MVP / później
Tryb jasny aplikacji (etap 13) · własna biblioteka zdjęć z pgvector (etap 13) · angielska wersja aplikacji (`next-intl`) · szablony premium po MVP (fotograf, kwiaciarnia, korepetycje, kancelaria, sala weselna, myjnia, piekarnia, joga, apartamenty, catering) · push do GitHub (opcjonalnie w etapie 12).
