---
description: Rozpocznij etap N projektu VORTBUILD (plan → akceptacja → kod)
argument-hint: <numer etapu>
---
Rozpoczynamy ETAP $ARGUMENTS projektu VORTBUILD.
1. Przeczytaj AGENTS.md, docs/PROGRESS.md, docs/DECISIONS.md oraz w VORTBUILD_MEGA_PROMPT.md część C → „ETAP $ARGUMENTS” i sekcje części A, do których się odwołuje.
2. Sprawdź, czy poprzedni etap jest oznaczony jako ukończony i czy `pnpm typecheck && pnpm test` przechodzą. Jeśli nie — zgłoś to i zatrzymaj się.
3. Przygotuj plan: podzadania (checkboxy), pliki do utworzenia/zmiany, zależności do zainstalowania, ryzyka, pytania do właściciela.
4. Zapisz plan w docs/PROGRESS.md (sekcja „Szczegóły bieżącego etapu”) i poczekaj na moją akceptację.
