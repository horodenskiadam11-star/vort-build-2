@AGENTS.md

# Wskazówki specyficzne dla Claude Code
- Na początku etapu używaj Plan Mode; plan zapisz w docs/PROGRESS.md w sekcji bieżącego etapu.
- Przy pracy nad generowaniem stron przeczytaj też: `docs/SITE_SCHEMA.md` i `docs/AI_PIPELINE.md` (celowo bez importu `@` — import ładowałby je do kontekstu w każdej sesji; ADR-011).
- Przy pracy nad płatnościami przeczytaj sekcje A3 i A13 w VORTBUILD_MEGA_PROMPT.md.
- Komendy projektu: /etap N, /checkpoint, /nowa-sekcja typ, /nowy-szablon id.
- Gdy kontekst się zapełnia: zakończ podzadanie, zrób /checkpoint i poproś o /clear.
- Środowisko właściciela: Windows 10 + PowerShell. Skrypty w `package.json` i hooki muszą działać na Windows (bez `rm -rf`, `export`, `VAR=x cmd`, `/dev/null` — używaj narzędzi Node).
