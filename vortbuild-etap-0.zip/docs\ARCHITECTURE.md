# ARCHITECTURE — VORTBUILD

> Streszczenie A4–A6 (+ przepływy z A10–A13) z `VORTBUILD_MEGA_PROMPT.md`. Decyzje uzasadnione w `docs/DECISIONS.md`.

## 1. Przegląd
Dwie aplikacje Next.js (App Router) w monorepo pnpm + Turborepo (ADR-002) i zestaw pakietów współdzielonych:

- **`apps/web`** (`vortbuild.pl`) — marketing, autoryzacja, aplikacja, edytor, API (webhooki, formularze, analityka, upload).
- **`apps/sites`** (`*.vortbuild.site` + domeny klientów) — jeden renderer multi-tenant opublikowanych stron (ADR-003). Bez kont, bez ciasteczek, tylko odczyt.
- **Zadania w tle** (`packages/jobs`, Trigger.dev) — generacja 2–5 min, eksport, zrzuty, domeny, sweepery (ADR-004).

Serce systemu: **`SiteDocument`** (Zod, `packages/site-schema`) — ten sam dokument produkuje pipeline AI, zmienia edytor, renderuje canvas / hosting / eksport (`SiteRenderer` w trybach `editor` / `hosted` / `export`). Szczegóły: `docs/SITE_SCHEMA.md`.

## 2. Kontekst systemu

```mermaid
flowchart LR
  U[Właściciel lokalu] -->|vortbuild.pl| WEB[apps/web<br/>marketing, aplikacja, edytor, API]
  V[Odwiedzający stronę klienta] -->|"*.vortbuild.site / domena klienta"| SITES[apps/sites<br/>renderer multi-tenant]
  WEB --> SB[(Supabase<br/>Postgres, Auth, Storage, Realtime)]
  WEB --> RD[(Upstash Redis<br/>cache, rate limit)]
  WEB -->|tasks.trigger| TR[Trigger.dev<br/>packages/jobs]
  WEB -->|Checkout, Portal| ST[Stripe]
  ST -->|webhooki| WEB
  WEB -->|revalidate| SITES
  SITES --> RD
  SITES --> SB
  SITES -->|formularze, beacon| WEB
  TR --> AN[Anthropic API]
  TR --> PX[Pexels API]
  TR --> SB
  TR --> FK[Fakturownia]
  TR --> VC[Vercel API<br/>domeny]
  WEB --> RS[Resend]
  TR --> RS
```

## 3. Aplikacje i routing

### `apps/web`
| Grupa | Trasy |
|---|---|
| `(marketing)` — statycznie / ISR | `/`, `/cennik`, `/szablony`, `/szablony/[slug]`, `/branze/[branza]`, `/przyklady`, `/regulamin`, `/polityka-prywatnosci`, `/cookies`, `/kontakt` |
| `(auth)` | `/logowanie`, `/rejestracja`, `/reset-hasla`, `/auth/callback`, `/weryfikacja-email` |
| `(app)` — chronione (middleware/proxy + layout) | `/panel`, `/nowa`, `/p/[projectId]` (generacja → edytor, widok zależny od `status`), `/p/[projectId]/podglad`, `/p/[projectId]/ustawienia`, `/p/[projectId]/formularze`, `/p/[projectId]/statystyki`, `/brand-kit[/id]`, `/domeny`, `/rozliczenia`, `/ustawienia` (konto) |
| admin (rola `admin`) | `/admin/*` |
| publiczne specjalne | `/preview/[token]` (noindex, znak wodny na Free, 7 dni). Canvas edytora **nie** ma trasy — iframe z portalem React (ADR-006). |
| dev | `/dev/sekcje` — galeria sekcji tylko w dev |

API (route handlers, tylko gdzie Server Actions nie pasują): `POST /api/webhooks/stripe`, `POST /api/forms/[siteId]` (CORS, Turnstile, rate limit), `POST /api/collect`, `GET /api/images/search`, `POST /api/uploads/sign`, `GET /api/exports/[id]/download`.
Wszystkie mutacje UI = Server Actions w `apps/web/features/*/actions.ts`: `requireUser()` → własność → Zod → `getEntitlements()` → rate limit → logika.

### `apps/sites`
- `middleware.ts` (albo `proxy.ts`, jeśli aktualny Next.js zmienił konwencję): `host` → rewrite na `/s/[host]/[[...slug]]`, z pominięciem `/api/*`, `/_next/*`, plików statycznych. Folder nie może zaczynać się od `_` (prywatny w App Router).
- `app/s/[host]/[[...slug]]/page.tsx`: `resolveSite(host)` → opublikowany `SiteDocument` → `<SiteRenderer mode="hosted" />`.
- `sitemap.xml`, `robots.txt`, `opengraph-image` per host; `app/api/revalidate` (sekret `SITES_REVALIDATE_SECRET`).

## 4. Pakiety i reguły zależności

```mermaid
flowchart BT
  schema[site-schema]
  sections[sections] --> schema
  templates[templates] --> schema
  templates --> sections
  ai[ai] --> schema
  ai --> templates
  ai --> images[images]
  ai -.->|wstrzyknięte repozytoria| db[db]
  exporter[exporter] --> schema
  exporter --> sections
```

- `site-schema` nie zależy od niczego wewnętrznego.
- Pakiety **nigdy** nie importują z `apps/*`; `apps/*` mogą zależeć od wszystkiego.
- `packages/ui` (shadcn/ui, tokeny aplikacji, Logo) — tylko dla aplikacji, **nie** dla stron klientów.
- Zależności `jobs`, `billing`, `domains`, `email` nie są określone w specyfikacji — ustalamy w etapie 1 (ADR) i egzekwujemy skryptem.
- Komponenty `packages/sections` są czyste (bez hooków); interakcje przez `data-vb-*` + `site-runtime.ts` (ADR-007).

## 5. Struktura repozytorium
Dokładna struktura: A6 w mega-prompcie. Skrót:
```
apps/web        apps/sites
packages/       site-schema · sections · templates · ai · images · exporter · billing · domains · db · email · jobs · ui · config
docs/           PRD · ARCHITECTURE · PROGRESS · DECISIONS · SITE_SCHEMA · SECTIONS_CATALOG* · TEMPLATES_CATALOG* · AI_PIPELINE · EVALS · RUNBOOK
scripts/        gen-catalogs · check-fonts-latin-ext · seed-demo · hooks/format-edited-file.mjs
.claude/ .cursor/rules/ .github/workflows/ci.yml
```
`*` — generowane z rejestrów (`pnpm catalogs`), nie edytujemy ręcznie.

## 6. Model danych (skrót A7)

```mermaid
erDiagram
  profiles ||--o{ subscriptions : ma
  profiles ||--o{ usage_counters : zuzywa
  profiles ||--o{ brand_kits : ma
  profiles ||--o{ projects : ma
  profiles ||--o{ assets : wgrywa
  profiles ||--o{ invoices : otrzymuje
  brand_kits |o--o{ projects : zasila
  projects ||--o{ project_versions : wersje
  projects ||--o{ generations : generacje
  projects ||--o{ ai_messages : czat
  projects ||--o{ deployments : publikacje
  projects ||--o{ preview_links : podglady
  projects ||--o{ exports : eksporty
  projects |o--o{ domains : domeny
  projects ||--o{ form_submissions : zgloszenia
  projects ||--o{ site_analytics_daily : statystyki
  projects ||--o{ abuse_reports : naduzycia
```

- RLS na każdej tabeli użytkownika: `user_id = auth.uid()`; tabele bez `user_id` (np. `project_versions`, `deployments`, `form_submissions`) — przez własność projektu. `stripe_events` — tylko service role.
- `projects.current_version_id` / `published_version_id` → `project_versions` (cykl FK z `project_versions.project_id`).
- Limity zużycia atomowo: `consume_usage` / `refund_usage` (A7.3).
- Realtime włączony dla `generations` (postęp na żywo).
- Retencja (A7.4): wersje wg planu (nigdy `current`/`published`), `events` ≤ 200, `artifacts` 30 dni.

## 7. Przepływy

### 7.1 Generacja strony
```mermaid
sequenceDiagram
  autonumber
  actor U as Użytkownik
  participant W as apps/web (createGeneration)
  participant B as packages/billing
  participant DB as Supabase
  participant T as Trigger.dev (generate-site)
  participant AI as Anthropic
  participant IMG as Pexels + sharp
  U->>W: opis + opcje + pliki
  W->>W: requireUser, e-mail zweryfikowany, Turnstile, Zod (15–1000 słów)
  W->>B: consumeUsage('generations')
  B->>DB: consume_usage() atomowo
  alt limit wyczerpany
    B-->>W: PlanLimitError
    W-->>U: modal upgrade
  else ok
    W->>DB: INSERT projects (generating) + generations (queued)
    W->>T: tasks.trigger(generationId, kolejka wg planu)
    W-->>U: przejście do /p/[projectId]
    U->>DB: subskrypcja Realtime wiersza generations
    loop kroki 01–11, checkpoint w artifacts
      T->>AI: structured output (Zod → JSON Schema)
      T->>IMG: wyszukiwanie, ranking, obróbka zdjęć
      T->>DB: current_step, progress, events, partial_document
      DB-->>U: oś kroków + podgląd progresywny
    end
    T->>DB: project_versions v1, projects.status = ready
    DB-->>U: widok zmienia się w edytor
  end
```
Błąd po naszej stronie → `refundUsage`, status `failed`, „Spróbuj ponownie” wznawia od checkpointu. Szczegóły: `docs/AI_PIPELINE.md`.

### 7.2 Poprawka przez czat AI
```mermaid
sequenceDiagram
  autonumber
  actor U as Użytkownik
  participant E as Edytor (zustand)
  participant W as runAiEdit (Server Action)
  participant B as packages/billing
  participant AI as Anthropic (SMART)
  participant DB as Supabase
  U->>E: wiadomość w czacie (+ zaznaczona sekcja)
  E->>W: runAiEdit(projectId, wiadomość, kontekst)
  W->>B: consumeUsage('ai_edits')
  W->>W: kontekst: zarys dokumentu, JSON sekcji, motyw, firma, pamięć, 10 ostatnich wiadomości
  W->>AI: prośba o EditPlan
  AI-->>W: EditPlan (intent, summary, ops, memoryUpdates)
  alt intent = clarify
    W->>B: refundUsage('ai_edits')
    W-->>E: pytanie doprecyzowujące
  else intent = edit
    W->>W: applyEditOps + SiteDocument.safeParse (1 próba naprawy)
    W->>DB: project_versions (ai_edit) + ai_messages + memory
    W-->>E: nowy dokument, changedSectionIds, podsumowanie
    E-->>U: podświetlenie zmian + „Cofnij tę zmianę”
  end
```

### 7.3 Publikacja i serwowanie strony
```mermaid
sequenceDiagram
  autonumber
  actor U as Użytkownik
  participant W as publishProject (apps/web)
  participant DB as Supabase
  participant S as apps/sites
  participant R as Upstash Redis
  actor V as Odwiedzający
  U->>W: Opublikuj (subdomena)
  W->>W: assertFeature(publish), limit stron, braki blocking, moderacja, walidacja subdomeny
  W->>DB: migawka wersji, published_version_id, deployments (live / superseded)
  W->>S: POST /api/revalidate (sekret, tag site:projectId)
  S->>R: usuń klucz site:host:HOST
  W-->>U: link + kod QR (na żywo w mniej niż 5 s)
  V->>S: GET brzytwa.vortbuild.site
  S->>S: rewrite host → /s/[host]/...
  S->>R: resolveSite(host)
  alt brak w cache
    S->>DB: opublikowana wersja (service role)
    S->>R: zapis (TTL 1 h)
  end
  S-->>V: HTML (SiteRenderer hosted) + site.js
```

### 7.4 Płatności i faktury
```mermaid
sequenceDiagram
  autonumber
  actor U as Użytkownik
  participant W as apps/web
  participant ST as Stripe
  participant WH as /api/webhooks/stripe
  participant DB as Supabase
  participant J as Trigger.dev
  participant F as Fakturownia
  U->>W: wybór planu (Pro/Max, miesięcznie/rocznie)
  W->>ST: Checkout Session (subscription, lookup_key, locale pl, NIP)
  W-->>U: przekierowanie do Checkout
  U->>ST: płatność
  ST->>WH: checkout.session.completed, customer.subscription.created
  WH->>WH: weryfikacja podpisu
  WH->>DB: INSERT stripe_events (idempotencja)
  WH->>DB: upsert subscriptions (plan z lookup_key, okres, status)
  ST->>WH: invoice.paid
  WH->>DB: nowy okres usage_counters
  WH->>J: issue-invoice
  J->>F: faktura VAT (KSeF wg konfiguracji)
  J->>DB: invoices (numer, PDF)
  U->>W: /rozliczenia?status=sukces
  W->>DB: getEntitlements → plan płatny
```
Anulowanie/nieudana płatność → `grace_until = now() + 7 dni` → `downgrade-sweeper` (co godzinę) zdejmuje publikacje ponad limit i odłącza domeny.

## 8. Tryby renderowania (`SiteRenderer`)
| Tryb | Gdzie | Różnice |
|---|---|---|
| `editor` | canvas w iframe (portal React) | nakładki edytora, re-init `site-runtime` po każdej zmianie |
| `hosted` | `apps/sites` | beacon analityki (Pro/Max), plakietka wg planu, „Zgłoś nadużycie”, nagłówki bezpieczeństwa |
| `export` | `packages/exporter` | ścieżki względne do `assets/`, `renderToStaticMarkup`, `site.js` + `sections.css` jako pliki |

## 9. Bezpieczeństwo w architekturze (A14)
- Zero HTML od modelu; `RichText` → whitelist elementów; URL-e walidowane; CSP bez `unsafe-eval` na stronach klientów.
- Osobna domena `vortbuild.site` — brak dostępu do ciasteczek aplikacji.
- Klucz service-role wyłącznie po stronie serwera (joby, webhooki, `apps/sites`); RLS na każdej tabeli; test „cudzy projekt = 404” dla każdej akcji.
- Rate limit (Upstash) na generacje, poprawki AI, wyszukiwanie zdjęć, upload, formularze, publikację.
- Upload: MIME + magic bytes, max 15 MB, ponowne kodowanie `sharp` (usuwa EXIF/GPS).
- Region UE (Frankfurt) dla bazy i plików.
