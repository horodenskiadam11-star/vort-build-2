// Hook PostToolUse dla Claude Code (ADR-011): formatuje Biome'em tylko plik, który agent właśnie edytował.
// Przenośny (Windows/macOS/Linux) i cichy: brak Biome, nieobsługiwany plik lub błąd = wyjście 0.
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { extname, join } from 'node:path';

const FORMATTABLE = new Set(['.ts', '.tsx', '.mts', '.cts', '.js', '.jsx', '.mjs', '.cjs', '.json', '.jsonc', '.css']);

let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  input += chunk;
});
process.stdin.on('end', () => {
  try {
    const payload = JSON.parse(input);
    const filePath = payload?.tool_input?.file_path;
    if (typeof filePath !== 'string' || !FORMATTABLE.has(extname(filePath).toLowerCase())) return;

    const root = process.env.CLAUDE_PROJECT_DIR ?? payload.cwd ?? process.cwd();
    const biome = join(root, 'node_modules', '@biomejs', 'biome', 'bin', 'biome');
    if (!existsSync(biome)) return;

    spawnSync(process.execPath, [biome, 'format', '--write', '--no-errors-on-unmatched', filePath], {
      cwd: root,
      stdio: 'ignore',
    });
  } catch {
    // Formatowanie nigdy nie blokuje pracy agenta.
  }
});
