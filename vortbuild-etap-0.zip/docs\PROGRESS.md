# PROGRESS — stan projektu VORTBUILD

## Bieżący etap: 1 — Fundament: monorepo, baza, CI (szkic planu gotowy, czeka na akceptację właściciela)
## Następny krok: ETAP 1. Najpierw właściciel usuwa blokery (Git, Node 24 LTS, pnpm, decyzja o bazie deweloperskiej — patrz niżej). Potem nowa sesja → `/etap 1`: zaległy commit i tag etapu 0, weryfikacja szkicu planu z sekcji „Szczegóły bieżącego etapu”, akceptacja, implementacja.

## Etapy
- [x] 0  Pamięć projektu i plan (30.09.2026 — commit i tag `etap-0` zaległe: brak Git na maszynie)
- [ ] 1  Fundament: monorepo, baza, CI
- [ ] 2  Design system, landing, auth, powłoka aplikacji
- [ ] 3  Kontrakt SiteDocument
- [ ] 4  Biblioteka sekcji + SiteRenderer + site-runtime
- [ ] 5  Szablony branżowe + demo
- [ ] 6  Pipeline AI + zdjęcia + zadania w tle + evals
- [ ] 7  Ekran generacji, „Ulepsz opis”, kreator krok po kroku
- [ ] 8  Edytor wizualny
- [ ] 9  Czat AI, pamięć projektu, Brand Kit
- [ ] 10 Płatności, limity, paywall, faktury
- [ ] 11 Publikacja, hosting, podgląd, formularze, analityka, eksport ZIP
- [ ] 12 Domeny (Max), white-label, eksport Next.js
- [ ] 13 Admin, moderacja, SEO VORTBUILD, wydajność, bezpieczeństwo, start

## Szczegóły bieżącego etapu

### ETAP 1 — szkic planu (przygotowany w etapie 0, czeka na akceptację)
**Cel:** działające monorepo, baza danych, CI. Kryteria akceptacji: część C → ETAP 1.

#### Blokery (właściciel)
- [ ] Git (np. `winget install Git.Git`)
- [ ] Node.js 24 LTS (np. `winget install OpenJS.NodeJS.LTS`) + `corepack enable` (pnpm)
- [ ] Baza deweloperska: Docker Desktop z WSL2 (lokalny Supabase — rekomendacja) **albo** projekt Supabase w chmurze (Frankfurt) na dev
- [ ] Konto GitHub + prywatne repo (potrzebne dla CI)

#### Podzadania
- [ ] 1.0 `git init -b main` + zaległy commit `chore(etap-0): project memory and docs` i tag `etap-0`; `.gitattributes` (`* text=auto eol=lf`), `.nvmrc` (24), `.npmrc`
- [ ] 1.1 Root monorepo: `package.json` (`packageManager`, `engines`), `pnpm-workspace.yaml` (`apps/*`, `packages/*`), `turbo.json` (build, dev, typecheck, lint, test, e2e), skrypty root z A6 (`catalogs` i `evals` jako zaślepki do etapów 5/6)
- [ ] 1.2 `packages/config`: `tsconfig.base.json` (strict, `noUncheckedIndexedAccess`, `moduleResolution: Bundler`), warianty `nextjs` i `library`, `biome.json` (`noExplicitAny: error`), root `biome.json` rozszerzający config
- [ ] 1.3 `apps/web` (:3000) i `apps/sites` (:3001): Next.js najnowsza stabilna, App Router, TS strict, Tailwind v4 (minimalnie), bez ESLint (Biome). Sprawdzić konwencję `middleware.ts` vs `proxy.ts` → ADR
- [ ] 1.4 Szkielety 13 pakietów z A6 (`@vortbuild/<nazwa>`): `package.json` z `exports`, `tsconfig.json`, `src/index.ts`; `scripts/check-deps.ts` egzekwujący reguły zależności A6 (w `pnpm lint`); ustalić zależności `jobs`/`billing`/`domains`/`email` → ADR
- [ ] 1.5 Env: `@t3-oss/env-nextjs` + Zod v4 w `apps/web/lib/env.ts` i `apps/sites/lib/env.ts`; zmienne potrzebne teraz (Supabase, URL-e) wymagane, reszta opcjonalna do swojego etapu
- [ ] 1.6 Supabase: `supabase/config.toml` (CLI), klienci `apps/web/lib/supabase/{server,client,admin}.ts` (`@supabase/ssr`), `admin.ts` z `import 'server-only'`; odświeżanie sesji w middleware/proxy
- [ ] 1.7 `packages/db`: schemat Drizzle z A7 — 12 enumów, 18 tabel, indeksy, FK (cykl `projects` ↔ `project_versions` przez `AnyPgColumn`), `drizzle.config.ts`; migracje do `supabase/migrations` (drizzle-kit z prefiksem `supabase` — do weryfikacji) → ADR
- [ ] 1.8 Migracje SQL (custom): RLS na każdej tabeli (tabele bez `user_id` przez własność projektu; `stripe_events` bez polityk = tylko service role), trigger `updated_at`, trigger `handle_new_user` → `profiles`, `consume_usage` / `refund_usage` (whitelist `p_kind` także w SQL, `set search_path = ''`, `revoke execute` dla `public`/`anon`/`authenticated`), publikacja Realtime dla `generations`
- [ ] 1.9 Seed `pnpm db:seed`: użytkownik testowy + admin (dane testowe tylko lokalnie, zapisane w pliku seedu)
- [ ] 1.10 Vitest (`projects` w root `vitest.config.ts`); testy DB na lokalnym Supabase: RLS (A nie widzi/nie zmienia/nie usuwa projektu B), `consume_usage` × 20 równolegle przy limicie 5 → dokładnie 5 sukcesów, `refund_usage` nie schodzi poniżej 0, odrzucenie nieznanego `p_kind`, brak dostępu do RPC dla `authenticated`
- [ ] 1.11 Playwright w `apps/web`: konfiguracja + smoke test (strona główna 200) w 390 i 1440 px
- [ ] 1.12 `.github/workflows/ci.yml`: cache pnpm, typecheck, lint, test (job z `supabase start`), build
- [ ] 1.13 `docs/RUNBOOK.md` (pierwsze uruchomienie), `/checkpoint`, tag `etap-1`

#### Zależności do instalacji (najnowsze stabilne, weryfikacja przy instalacji)
`turbo`, `typescript`, `@biomejs/biome`, `vitest`, `@playwright/test`, `next`, `react`, `react-dom`, `tailwindcss`, `@tailwindcss/postcss`, `zod`, `@t3-oss/env-nextjs`, `@supabase/supabase-js`, `@supabase/ssr`, `drizzle-orm`, `drizzle-kit`, `postgres`, `supabase` (CLI), `tsx`, `server-only`.

#### Ryzyka
- `consume_usage` jako `security definer` jest domyślnie wywoływalna przez PostgREST RPC przez każdego zalogowanego — z cudzym `p_user`. Bez `revoke execute` to dziura (można zużyć komuś limit). W planie: revoke + test.
- Drizzle nie zarządza RLS ani schematem `auth` — polityki i triggery w custom migracjach SQL; drizzle-kit nie może dotykać `auth`.
- Dwa mechanizmy migracji (drizzle-kit i Supabase CLI) muszą mieć jedno źródło plików → ADR.
- Docker Desktop na Windows (WSL2) bywa kłopotliwy; alternatywa chmurowa spowalnia testy i wymaga sekretów w CI.
- Zgodność Zod v4 z `@t3-oss/env-nextjs` i konwencje najnowszego Next.js — sprawdzić przy instalacji.

## Decyzje czekające na właściciela
| # | Decyzja | Potrzebna przed |
|---|---|---|
| 1 | Instalacja Git / Node / pnpm / Docker — samodzielnie czy przez agenta (winget) | etap 1 |
| 2 | Baza deweloperska: lokalny Supabase w Dockerze (rekomendacja) czy projekt w chmurze | etap 1 |
| 3 | GitHub: konto, nazwa prywatnego repo | etap 1 (CI) |
| 4 | Domeny: `vortbuild.pl` czy `.com` dla aplikacji; zakup `vortbuild.site` (warto od razu sprawdzić dostępność) | przed etapem 11 |
| 5 | VAT w Stripe: Stripe Tax czy stała stawka (z księgowym) | etap 10 |
| 6 | Fakturownia czy inFakt; konfiguracja KSeF (z księgowym) | etap 10 |
| 7 | Rejestrator `.pl`, jeśli Vercel go nie obsługuje (np. OVHcloud) | etap 12 |
| 8 | Dokumenty prawne (regulamin, prywatność, cookies, DPA) — prawnik | przed startem |
| 9 | Wartości w tabeli porównawczej na landingu (agencja / kreator / VORTBUILD) | etap 2 |

## Znane problemy / dług techniczny
- Etap 0 bez commita i tagu `etap-0` — na maszynie brak Git (30.09.2026). Do zrobienia jako podzadanie 1.0.
- Hook formatowania (`.claude/settings.json` → `scripts/hooks/format-edited-file.mjs`) wymaga Node w PATH; do czasu instalacji każda edycja pliku przez agenta zgłasza niegroźny błąd hooka.
- Niespójności w specyfikacji (do rozstrzygnięcia we wskazanym etapie):
  - A8.5 mówi „podstrony od Pro”, ale `plans.ts` (A3.3) nie ma odpowiedniej flagi (np. `multipage`). Dodanie flagi zmienia strukturę A3.3 → decyzja właściciela (etap 3/10).
  - A9.4 daje planowi Free tylko pierwszą paletę szablonu, a A3.2 i A11.2 pozwalają bez limitu edytować pojedyncze kolory ręcznie. Czy na Free ręczna zmiana kolorów jest dozwolona? → decyzja właściciela (etap 8/10).
  - A10.2 uruchamia `vision_uploads` równolegle z `analyze_brief`, a brief potrzebuje etykiet zdjęć i OCR menu z kroku 03 → rozstrzygnięcie w etapie 6 (propozycja w `docs/AI_PIPELINE.md` §12).
  - A9.2 („sekcja ukryta z NeedsInput”) vs A10.4 („sekcja pominięta”) dla `testimonials` bez opinii → przyjąć pominięcie (A10.4 to twarda reguła), potwierdzić w etapie 6.
  - Wzorce kodu A8 częściowo w składni Zod 3 (`z.record` z jednym argumentem, `.deepPartial()`, `z.string().url()`) → dostosowanie do Zod v4 bez zmiany semantyki w etapie 3 (`docs/SITE_SCHEMA.md` §10).

## Dziennik sesji
### 2026-09-30 — etap 0
- Zrobione: `VORTBUILD_MEGA_PROMPT.md` zapisany jako źródło prawdy; pliki pamięci wg A15 (`AGENTS.md`, `CLAUDE.md`, `docs/PROGRESS.md`, `docs/DECISIONS.md` z ADR-001…011, 6 reguł `.cursor/rules/*.mdc`, 4 komendy `.claude/commands/*.md`, `.claude/settings.json`); dokumentacja `docs/PRD.md`, `docs/ARCHITECTURE.md` (diagramy mermaid: kontekst, pakiety, ER, generacja, edycja AI, publikacja, płatności), `docs/SITE_SCHEMA.md`, `docs/AI_PIPELINE.md`, `docs/RUNBOOK.md` (szkielet), `docs/EVALS.md`; `.env.example`, `.gitignore`; `scripts/hooks/format-edited-file.mjs`; szkic planu etapu 1.
- Odstępstwa od wzorców A15 (hook przenośny na Windows, precyzyjne blokady `.env`, `CLAUDE.md` bez eager-importu docs) → ADR-011.
- Poprawka w mega-prompcie: w komentarzu SQL tabeli `domains` usunięto artefakt wklejania (`[www.brzytwa.pl](https://…)` → `www.brzytwa.pl`).
- Problemy: brak Git, Node, pnpm i Dockera na maszynie → brak commita i tagu `etap-0`, pakiety niezainstalowane (zgodnie z etapem 0).
- Następnym razem: usunąć blokery, `/etap 1`, zacząć od podzadania 1.0.
