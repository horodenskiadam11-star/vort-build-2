---
description: Checkpoint — testy, PROGRESS, DECISIONS, katalogi, commit (i tag etapu)
---
Zrób checkpoint:
1. Uruchom `pnpm typecheck && pnpm lint && pnpm test`. Napraw błędy, które wprowadziłeś.
2. Zaktualizuj docs/PROGRESS.md: odhacz podzadania, dopisz wpis w „Dzienniku sesji” (data, zrobione, problemy, następnym razem), ustaw „Następny krok”.
3. Dopisz nowe decyzje do docs/DECISIONS.md.
4. Jeśli zmieniały się sekcje/szablony — `pnpm catalogs`.
5. Commit w konwencji Conventional Commits. Jeśli etap ukończony — tag `etap-N`.
6. Podsumuj mi w 5 punktach, co zrobiłeś i co dalej.
