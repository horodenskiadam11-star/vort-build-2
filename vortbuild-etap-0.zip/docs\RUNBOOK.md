# RUNBOOK — uruchamianie, deploy, sekrety, awarie

> Szkielet (etap 0). Uzupełniany w każdym etapie, w którym dochodzi nowa usługa lub procedura. Wpisy `TODO(etap-N)` = do wypełnienia w danym etapie.

## 1. Wymagania lokalne
| Narzędzie | Wersja | Po co | Status (30.09.2026) |
|---|---|---|---|
| Git | aktualna | repozytorium, commity po etapach | brak na maszynie właściciela |
| Node.js | 24 LTS | aplikacje, skrypty, hook formatowania | brak |
| pnpm | 10.x (przez `corepack enable`) | monorepo | brak |
| Docker Desktop (WSL2) | aktualna | lokalny stack Supabase (baza, Auth, Storage, Realtime) | brak — decyzja w etapie 1 |
| Supabase CLI | devDependency | migracje, lokalny stack | etap 1 |
| Stripe CLI | aktualna | webhooki lokalnie | etap 10 |

Windows: skrypty w `package.json` muszą być przenośne (bez `rm -rf`, `export`, `VAR=x cmd`); pliki z końcami linii LF (`.gitattributes`, etap 1).

## 2. Pierwsze uruchomienie
TODO(etap-1):
1. `corepack enable` → `pnpm install`
2. `cp .env.example .env.local` (w PowerShell: `Copy-Item .env.example .env.local`) i uzupełnienie wartości
3. `pnpm supabase start` → `pnpm db:migrate` → `pnpm db:seed`
4. `pnpm dev` — `apps/web` na :3000, `apps/sites` na :3001

## 3. Codzienne komendy
| Komenda | Działanie |
|---|---|
| `pnpm dev` / `pnpm dev --filter web` | serwery deweloperskie |
| `pnpm typecheck` · `pnpm lint` · `pnpm test` · `pnpm e2e` | jakość (wymagane przed commitem etapu) |
| `pnpm db:generate` · `pnpm db:migrate` · `pnpm db:seed` | schemat i dane |
| `pnpm catalogs` | regeneracja katalogów sekcji i szablonów |
| `pnpm evals` | testy jakości generacji → `docs/EVALS.md` |
| `pnpm trigger:dev` | lokalny worker Trigger.dev |

## 4. Zmienne środowiskowe i sekrety
- Wzór: `.env.example` (część D). Walidacja przy starcie: `lib/env.ts` w obu aplikacjach.
- Sekrety tylko po stronie serwera; `SUPABASE_SERVICE_ROLE_KEY` nigdy w kodzie klienta ani w zmiennych `NEXT_PUBLIC_*`.
- Agent AI ma zablokowany odczyt `.env`, `.env.local`, `.env.*.local`, `.env.production` (`.claude/settings.json`).
- Rotacja kluczy: TODO(etap-13) — procedura per dostawca (Supabase, Stripe, Anthropic, Trigger.dev, Upstash, Resend, Vercel).

## 5. Środowiska i deploy
TODO(etap-2/11):
- Vercel — projekt `vortbuild-web` (domena aplikacji) i `vortbuild-sites` (wildcard `*.vortbuild.site` + domeny klientów).
- Supabase — projekt produkcyjny w regionie UE (Frankfurt), PITR włączone.
- Trigger.dev — deploy zadań z `packages/jobs` (rozszerzenie build Playwright).
- Stripe — webhook produkcyjny `https://<domena aplikacji>/api/webhooks/stripe`, zdarzenia z A13.1.
- Kolejność wdrożenia migracji względem kodu: TODO(etap-1).

## 6. Webhooki lokalnie
TODO(etap-10): `stripe listen --forward-to localhost:3000/api/webhooks/stripe` → `STRIPE_WEBHOOK_SECRET` z wyjścia komendy.

## 7. Procedury awaryjne
| Sytuacja | Procedura |
|---|---|
| Generacje stoją w kolejce | TODO(etap-6): panel Trigger.dev, limity współbieżności, status Anthropic |
| Wzrost kosztu AI | TODO(etap-6): alert w adminie, przełączenie kroków pomocniczych na tańszy model (env) |
| Strona klienta z phishingiem / nadużycie | TODO(etap-13): `/admin` → wyłączenie strony jednym kliknięciem, unieważnienie cache hosta |
| Webhook Stripe nie dotarł | TODO(etap-10): ponowienie z panelu Stripe (idempotencja przez `stripe_events`) |
| Domena klienta nie działa | TODO(etap-12): stan w `domains`, konfiguracja w Vercel API, typowe konflikty (AAAA, CAA) |
| Awaria bazy / utrata danych | TODO(etap-13): odtworzenie z PITR — test odtwarzania wykonywany i opisany tutaj |

## 8. Kopie zapasowe
TODO(etap-13): PITR w Supabase (plan płatny), data ostatniego testu odtwarzania, czas odtworzenia.
