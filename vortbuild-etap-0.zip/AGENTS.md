# VORTBUILD — zasady dla agentów AI

## Produkt w 3 zdaniach
VORTBUILD to AI kreator stron dla lokalnych biznesów (gastronomia, barberzy, beauty, usługi) w Polsce.
Użytkownik opisuje firmę (≤ 1000 słów), pipeline AI w 2–3 min składa stronę z gotowych, dopracowanych sekcji.
Plany: Free (5 stron/mies., bez eksportu), Pro 80 zł (eksport, subdomena), Max 150 zł (domeny, white-label).
Pełna specyfikacja: VORTBUILD_MEGA_PROMPT.md (źródło prawdy). Skrót: docs/PRD.md.

## Zanim cokolwiek zrobisz
1. Przeczytaj docs/PROGRESS.md (stan etapów, ostatnia sesja, znane problemy).
2. Przeczytaj docs/DECISIONS.md (nie łam przyjętych decyzji bez nowego ADR).
3. Uruchom `git log --oneline -15`.
4. Pracujesz wyłącznie nad bieżącym etapem. Zaczynasz od planu i czekasz na akceptację.

## Złote zasady architektury
- AI nigdy nie generuje HTML. AI produkuje/zmienia `SiteDocument` (Zod, packages/site-schema) przez `EditOp`.
- Jedna sekcja = jeden komponent w packages/sections, czysty (bez hooków), interakcje przez `data-vb-*` + site-runtime.
- Ten sam `SiteRenderer` renderuje canvas edytora, hosting (apps/sites) i eksport ZIP.
- Uprawnienia i limity wyłącznie przez packages/billing (`getEntitlements`, `assertFeature`, `consumeUsage`). Nigdy w kliencie.
- Ceny/limity tylko w packages/billing/src/plans.ts. Nazwy modeli AI tylko w env.
- AI nie wymyśla faktów (ceny, adresy, godziny, opinie) → `NeedsInput`.
- Pakiety nie importują z apps/*. Kierunek zależności: site-schema ← sections ← templates ← ai.

## Standard kodu
- TypeScript strict, zero `any`/`@ts-ignore`; typy z `z.infer`.
- Server Actions: `requireUser()` → własność zasobu → walidacja Zod → entitlements → logika.
- Każdy ekran: loading / empty / error / success; mobile-first; UI po polsku.
- Pliki < 300 linii. Nazwy: komponenty PascalCase, pliki kebab-case, funkcje camelCase.
- Klasy Tailwind statyczne (bez składania ze stringów).
- Testy: logika czysta (applyEditOps, scoring, entitlements, migracje) — Vitest; przepływy — Playwright.

## Komendy
- `pnpm dev` — wszystkie aplikacje | `pnpm dev --filter web`
- `pnpm typecheck` · `pnpm lint` · `pnpm test` · `pnpm e2e`
- `pnpm db:generate` · `pnpm db:migrate` · `pnpm db:seed`
- `pnpm catalogs` — regeneruje docs/SECTIONS_CATALOG.md i docs/TEMPLATES_CATALOG.md
- `pnpm evals` — testy jakości generacji (wynik do docs/EVALS.md)
- `pnpm trigger:dev` — lokalny worker zadań

## Gdzie co jest
- Kontrakt strony: packages/site-schema · Sekcje: packages/sections · Szablony: packages/templates
- Pipeline AI: packages/ai (prompty w src/prompts) · Zdjęcia: packages/images · Zadania: packages/jobs
- Plany i płatności: packages/billing · Baza: packages/db · Domeny: packages/domains · Eksport: packages/exporter
- Aplikacja: apps/web · Hosting stron: apps/sites

## Koniec każdej sesji
1. `pnpm typecheck && pnpm lint && pnpm test` przechodzą.
2. Zaktualizuj docs/PROGRESS.md (sekcja „Dziennik” + checklista etapu + „Następny krok”).
3. Nowe decyzje → docs/DECISIONS.md.
4. Commit (Conventional Commits, np. `feat(editor): inline text editing`).
