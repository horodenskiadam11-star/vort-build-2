# SITE_SCHEMA — kontrakt `SiteDocument`

> Status: **opis kontraktu przed implementacją** (etap 0). Od etapu 3 jedynym źródłem prawdy jest kod Zod w `packages/site-schema`; ten dokument aktualizujemy przy każdej zmianie schematu. Pełne wzorce kodu: A8 w `VORTBUILD_MEGA_PROMPT.md`.

## 1. Rola
Każda strona klienta to **jeden dokument JSON** (`SiteDocument`). Ten sam dokument:
- produkuje pipeline AI (`packages/ai`),
- zmienia edytor — ręcznie i przez czat AI — wyłącznie operacjami `EditOp`,
- renderują: canvas edytora, hosting `apps/sites` i eksporter ZIP (`SiteRenderer`),
- jest wersjonowany w `project_versions` (niezmienne migawki).

## 2. Zasady nienaruszalne
1. Zod w `packages/site-schema` jest jedynym źródłem prawdy. Typy = `z.infer`.
2. Każde pole tekstowe ma `.max()` — limity projektowe chronią układ.
3. Brak surowego HTML-a. Tekst sformatowany = `RichText` (ograniczony markdown) parsowany do elementów React.
4. Linki tylko `https:`, `http:`, `tel:`, `mailto:`, `https://wa.me/...` albo kotwice sekcji — walidowane (`safeUrl`).
5. Każda zmiana struktury = podbicie `schemaVersion` + migracja w `migrate.ts` + test. Stare dokumenty zawsze da się otworzyć.

## 3. Struktura dokumentu
```
SiteDocument
├─ schemaVersion: 1
├─ templateId, locale ('pl')
├─ business: BusinessInfo            ← dane firmy, cel powiązań $bind
├─ theme: ThemeTokens                ← design tokens → CSS variables
├─ globals
│  ├─ navbar: NavbarSection
│  ├─ footer: FooterSection
│  ├─ floatingCta?  { enabled, cta, showOn: mobile|all }
│  └─ announcement? { text ≤ 90, link? }
├─ pages[1..8]                       ← MVP: one-page
│  └─ Page { id, slug "/…", title ≤ 60, seo { title ≤ 60, description ≤ 160, noindex }, sections[1..30] }
├─ assets: record<uuid, { url, width, height, thumbhash?, attribution? }>   ← denormalizacja do renderu bez DB
├─ seo { siteTitle ≤ 60, defaultDescription ≤ 160, keywords ≤ 12, ogImageAssetId?, jsonLd }
├─ integrations { googleMapsEmbed, formsEndpointId? }
└─ meta { generatedBy?, generationId? }
```
`seo.jsonLd` generowany **deterministycznie** z `business` (typ schema.org wg branży: `Restaurant`, `BarberShop`/`HairSalon`, `BeautySalon`, `AutoRepair`, `Dentist`, `ExerciseGym`, `LodgingBusiness`…).

## 4. Prymitywy (`primitives.ts`)
| Prymityw | Znaczenie |
|---|---|
| `Id` | `^[a-zA-Z0-9_-]{8,24}$` — nanoid(10) dla sekcji i elementów |
| `Hex` | `#RRGGBB` |
| `RichText(max)` | `{ md }` — `**pogrubienie**`, `*kursywa*`, `[link](url)`, listy `- `, akapity. Bez HTML. |
| `Bindable(max)` | tekst albo `{ $bind: BusinessPath }` — zmiana danych firmy w jednym miejscu = zmiana wszędzie |
| `BusinessPath` | `business.name`, `.tagline`, `.phone`, `.email`, `.address.full`, `.address.city`, `.hours.today`, `.bookingUrl` |
| `NeedsInput` | `{ needsInput: true, hint ≤ 120 }` — fakt, którego AI nie zna; edytor pokazuje „Uzupełnij” |
| `ImageRef` | `{ assetId, alt ≤ 160, focalPoint?, illustrative }` — `illustrative` = zdjęcie poglądowe (np. stockowa pizza) |
| `LinkAction` | `url` (safeUrl, newTab) · `tel` · `mailto` · `whatsapp` · `section` · `booking` · `map` · `page` |
| `Cta` | `{ label 2–28, action: LinkAction, style: primary / secondary / ghost }` |

## 5. Dane firmy (`BusinessInfo`)
Nazwa (≤ 60), branża (`IndustryId` — 38 wartości od `restaurant` do `other`), tagline, krótki opis, adres **albo** `NeedsInput`, geo, obszar działania, telefon **albo** `NeedsInput`, e-mail, godziny (7 dni × do 3 przedziałów `HH:MM`) **albo** `NeedsInput`, godziny specjalne, przedział cen, link rezerwacji, social (Instagram, Facebook, TikTok, Google, Booksy, Pyszne, Glovo, Uber Eats, YouTube), udogodnienia (parking, wifi, wheelchair, pet_friendly, card, blik, garden, delivery, takeaway, kids, air_con), języki, dane prawne (nazwa firmy, NIP).
Status „Otwarte teraz”: `getOpenStatus(hours, now, 'Europe/Warsaw')` — obsługa przedziałów przez północ i dni zamkniętych.

## 6. Motyw (`ThemeTokens`)
`mode` (light/dark) · `colors` (bg, surface, text, textMuted, border, primary + primaryContrast, accent + accentContrast) · `typography` (pairing, headingWeight, headingCase, scale compact/normal/large, letterSpacing) · `shape` (radius none–xl, buttonStyle solid/outline/pill/underline) · `imageTreatment` · `density` (airy/balanced/compact) · `motion` (none/subtle/lively).
Mapowanie na CSS variables w `packages/sections/src/theme-style.ts`: `--c-bg`, `--c-surface`, `--c-text`, `--c-primary`, `--font-heading`, `--font-body`, `--radius`, `--space-section`… Po ustaleniu motywu zawsze **deterministyczna korekta kontrastu** WCAG AA (4.5:1 tekst, 3:1 duże nagłówki i UI) w OKLCH.

## 7. Sekcje
### Koperta (wspólna dla wszystkich typów)
`{ id, type, variant, props, style: SectionStyle, hidden, hideOn: none/mobile/desktop }`
`SectionStyle`: `tone` (default/muted/inverted/primary/image), `spacing` (sm/md/lg), `align`, `anchor` (`^[a-z0-9-]{2,30}$`), `backgroundImage` (gdy `tone = image`).

### 27 typów sekcji (warianty i zastosowanie — A9.2)
| Typ | Warianty |
|---|---|
| `navbar` | classic, centered-logo, transparent-overlay, minimal-burger |
| `hero` | fullscreen-image, split-image, big-type, collage-3, video-bg, carousel |
| `about` | split-image, story-timeline, quote-owner, stats-inline |
| `services` | cards-icons, cards-photo, list-detailed, bento |
| `priceList` | table-classic, categories-accordion, two-column-dotted |
| `menu` | tabs, list-elegant, cards-photo, board-chalk |
| `gallery` | masonry, grid-uniform, carousel, featured-plus-grid |
| `testimonials` | cards, single-large, marquee — **tylko opinie podane przez użytkownika** |
| `team` | grid-portraits, cards-booking, list-bio |
| `openingHours` | table, card-with-status, inline-compact |
| `location` | map-split, map-full, address-card, service-area |
| `contact` | form-split, form-centered, cards-channels |
| `cta` | banner-gradient, image-overlay, split-phone |
| `faq` | accordion, two-column |
| `features` | icons-grid, alternating, checklist |
| `stats` | row-numbers, cards — **liczby tylko z opisu** |
| `process` | steps-horizontal, timeline-vertical |
| `beforeAfter` | slider, pairs-grid — **zdjęcia tylko od użytkownika** |
| `pricingPackages` | cards-3, rooms, memberships |
| `logos` | row-grayscale, badges |
| `promoBanner` | strip, card-highlight |
| `socialFeed` | grid-instagram, strip |
| `video` | embed-16-9, background-loop |
| `reservation` | booking-link, form-table, embed |
| `deliveryLinks` | buttons, cards |
| `richText` | prose, two-column |
| `footer` | columns, minimal, big-brand |

Wzorzec propsów: `menu` w A8.4 (kategorie → dania z ceną `PLN` albo `NeedsInput`, tagi, 14 alergenów UE, warianty np. 32/40 cm). Katalog pól wszystkich sekcji generuje `pnpm catalogs` do `docs/SECTIONS_CATALOG.md` (od etapu 4).

## 8. Operacje edycji (`EditOp`) — jedyna droga zmiany dokumentu
| Operacja | Działanie |
|---|---|
| `updateSectionProps` | deep-merge `patch` do propsów sekcji, potem walidacja |
| `setSectionVariant` | zmiana wariantu |
| `setSectionStyle` | częściowa zmiana `SectionStyle` |
| `addSection` | wstawienie po `afterSectionId` (albo na początku) |
| `removeSection` / `moveSection` / `duplicateSection` | struktura strony |
| `updateTheme` | częściowa zmiana motywu (deep partial) |
| `updateBusiness` | częściowa zmiana danych firmy (deep partial) → powiązania `$bind` aktualizują się same |
| `updateGlobals` | navbar, footer, floatingCta, announcement |
| `replaceImage` | podmiana zdjęcia w ścieżce (`assetId` albo `query` do wyszukania) — operacja asynchroniczna |
| `regenerateSection` | przepisanie sekcji przez AI wg instrukcji — asynchroniczna |
| `addPage` | nowa podstrona z blueprintem sekcji |
| `updatePageSeo` | SEO podstrony |

### `applyEditOps(doc, ops) → { doc, changedSectionIds, inversePatch }`
- Czysta funkcja (Immer `produceWithPatches`), plik `packages/site-schema/src/apply.ts`.
- Po zastosowaniu **zawsze** `SiteDocument.safeParse`. Niepowodzenie = odrzucenie całej paczki (atomowo); błąd wraca do modelu jako feedback (max 2 próby naprawy).
- `inversePatch` zasila undo; edytor ręczny i czat AI używają tych samych operacji (ADR-008).

## 9. Wersjonowanie i migracje
- `schemaVersion: z.literal(1)` na start; `migrate.ts` przyjmuje dokument dowolnej wcześniejszej wersji i podnosi go krokami do bieżącej.
- Każda migracja ma test na zapisanym dokumencie z poprzedniej wersji.
- `project_versions.schema_version` pozwala migrować leniwie przy odczycie.

## 10. Uwagi implementacyjne na etap 3 (Zod v4)
Wzorce kodu w A8 są pisane częściowo w składni Zod 3. W Zod v4 (wybranym w A5) trzeba — **bez zmiany semantyki** — m.in.:
- `z.record(z.unknown())` → `z.record(z.string(), z.unknown())` (v4 wymaga schematu klucza).
- `.deepPartial()` nie istnieje → własny helper `deepPartial()` w `primitives.ts` (przewidziane w A8.6).
- `z.string().url()` / `.email()` / `.uuid()` są w v4 przestarzałe na rzecz `z.url()`, `z.email()`, `z.uuid()`; `z.uuid()` w v4 jest zgodny z RFC (UUID v4 z `gen_random_uuid()` przechodzi).
- Sprawdzić, jak `.default()` wewnątrz `z.discriminatedUnion` i `z.toJSONSchema` współgrają ze structured output modelu (pola z domyślną wartością mogą być wymagane w JSON Schema trybu `output`).
Każde odstępstwo zapisujemy w ADR.
