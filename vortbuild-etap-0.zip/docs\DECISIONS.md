# DECISIONS — rejestr decyzji architektonicznych

## ADR-001: AI generuje dokument JSON, nie HTML
Kontekst: jakość i przewidywalność stron. Decyzja: pipeline produkuje SiteDocument (Zod) wypełniający ręcznie
zaprojektowane sekcje. Konsekwencje: wysoka jakość, bezpieczeństwo (brak XSS), łatwa edycja; mniejsza „dowolność” — rekompensujemy bogatą biblioteką wariantów.

## ADR-002: Monorepo pnpm + Turborepo
Wspólne pakiety (schema, sections) używane przez edytor, hosting i eksport.

## ADR-003: Hosting multi-tenant zamiast deploymentu per strona
apps/sites renderuje dowolny host z opublikowanej wersji; publikacja = zmiana wskaźnika + unieważnienie cache (< 5 s).

## ADR-004: Trigger.dev dla długich zadań
Generacja trwa 2–5 min — poza limitami zwykłych funkcji serverless; potrzebne retry, checkpointy, kolejki z priorytetem.

## ADR-005: Osobna domena dla stron klientów (vortbuild.site)
Izolacja ciasteczek i reputacji domeny aplikacji.

## ADR-006: Canvas edytora = iframe z portalem React
Izolacja CSS strony od CSS aplikacji, prawdziwe media queries dla urządzeń, wspólny stan bez postMessage.

## ADR-007: Sekcje jako czyste komponenty + wspólny sections.css + site-runtime
Jeden CSS zbudowany raz, motyw przez CSS variables; interakcje w małym skrypcie vanilla — działa w edytorze, hostingu i eksporcie statycznym.

## ADR-008: Edycje przez domenowe EditOp zamiast surowego JSON Patch
Model popełnia mniej błędów na operacjach wysokiego poziomu; walidacja atomowa; wspólne undo dla edycji ręcznych i AI.

## ADR-009: Domeny przez interfejs DomainRegistrar (pierwszy dostawca: Vercel)
Możliwość dodania rejestratora z obsługą .pl bez zmian w reszcie systemu.

## ADR-010: Zdjęcia — Pexels automatycznie, Unsplash tylko ręcznie
Zgodność z wytycznymi API (Unsplash: hotlinking, nieautomatyczne użycie); długoterminowo własna biblioteka.

## ADR-011: Adaptacje wzorców pamięci agenta (Claude Code na Windows)
Kontekst: wzorce z A15.2 i A15.7 zakładały powłokę uniksową, a część z nich dawała niezamierzone skutki. Środowisko właściciela to Windows 10 + PowerShell 5.1.
Decyzja:
1. Hook `PostToolUse` wywołuje `node scripts/hooks/format-edited-file.mjs`, który formatuje Biome'em **tylko edytowany plik**. Wzorzec `pnpm -s biome format --write . > /dev/null 2>&1 || true` nie działa w PowerShell 5.1 (`||`, `/dev/null`) i formatował całe repo po każdej edycji. Brak zainstalowanego Biome albo nieobsługiwane rozszerzenie = ciche wyjście 0.
2. Blokada odczytu sekretów przez konkretne wzorce (`**/.env`, `**/.env.local`, `**/.env.*.local`, `**/.env.production`) zamiast `Read(.env*)`, które blokowało też `.env.example` (reguły `deny` mają pierwszeństwo przed `allow`).
3. `CLAUDE.md` wskazuje `docs/SITE_SCHEMA.md` i `docs/AI_PIPELINE.md` zwykłą ścieżką zamiast importu `@` — import ładuje plik w każdej sesji, a te dokumenty są potrzebne tylko przy pracy nad generowaniem.
4. Dodano `Bash(git tag *)` do dozwolonych (komenda `/checkpoint` taguje etapy) i `Bash(git push -f*)` do zabronionych.
Alternatywy: dosłowne wzorce z A15 (niedziałający hook, zablokowany `.env.example`, stale rosnący kontekst).
Konsekwencje: hook wymaga Node w PATH — do czasu instalacji Node każda edycja zgłasza niegroźny błąd hooka. Reguły `Bash(...)` nie obejmują narzędzia PowerShell w Claude Code; ewentualne reguły dla PowerShell dodajemy dopiero po sprawdzeniu składni w aktualnej dokumentacji.

## Szablon nowego ADR
## ADR-0XX: Tytuł
Kontekst: … Decyzja: … Alternatywy: … Konsekwencje: …
