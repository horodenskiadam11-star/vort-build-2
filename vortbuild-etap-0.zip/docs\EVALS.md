# EVALS — historia wyników testów jakości generacji

> Wypełniane przez `pnpm evals` (od etapu 6). Rubryka: załącznik E3 w `VORTBUILD_MEGA_PROMPT.md`. Każda zmiana promptów = nowy wpis; regresja > 5% względem poprzedniego wyniku = nie mergujemy.

## Zestaw testowy
12 opisów (po jednym na szablon), różna jakość: chaotyczny dyktowany / krótki / bardzo szczegółowy. Wzorce: E1.1 (barber, dyktowany) i E1.2 (pizzeria, krótki). Pozostałe 10 — do przygotowania w etapie 6.

## Wyniki

| Data | Commit | Zmiana | Śr. wynik | Fakty | Szablon | Treść | Zdjęcia | Estetyka | Mobile | SEO | Kompletność | Czas p50 / p90 | Koszt śr. | Uwagi |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

_Brak wyników — pierwsze uruchomienie w etapie 6._

## Ręczna kalibracja sędziego (raz w tygodniu, 5 losowych stron)

| Data | Strona | Ocena właściciela | Ocena sędziego | Różnica | Uwagi |
|---|---|---|---|---|---|
