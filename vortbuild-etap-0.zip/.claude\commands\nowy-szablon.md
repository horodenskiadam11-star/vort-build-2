---
description: Scaffold szablonu branżowego wg A9.4 (definicja, palety, fonty, blueprint, demo)
argument-hint: <id-szablonu>
---
Tworzymy szablon branżowy `$ARGUMENTS`.

Zanim zaczniesz: przeczytaj w VORTBUILD_MEGA_PROMPT.md sekcje A9.4 (`TemplateDefinition` i tabela szablonów), A9.5 (pary fontów), A9.6 (scoring) i A8.3 (motyw). Sprawdź w `packages/templates/src/registry.ts`, czy id nie jest zajęte.

1. **Definicja** — `packages/templates/src/<grupa>/<id>.ts` (grupa: `gastro` / `beauty` / `services` / `health` / `stay`): id, nazwa, opis w 1 zdaniu, `tier`, `industries` z `fit` 1–3, `styleTags`, `mode`, `copyVoice`, `imageDirection`.
2. **Blueprint** — kolejność sekcji z wariantami istniejącymi w rejestrze sekcji; sekcje warunkowe z `when` (np. `testimonials` tylko gdy są opinie, `beforeAfter` tylko gdy są pary zdjęć).
3. **3 presety palet** nazwane po polsku (np. „Terakota”, „Oliwka”, „Noc”). Każdy przechodzi kontrast WCAG AA (4.5:1 tekst, 3:1 duże nagłówki i elementy UI). `themePresets[0]` to jedyna paleta dostępna na planie Free.
4. **2–3 pary fontów** wyłącznie z katalogu A9.5 (potwierdzony `latin-ext`).
5. **`demo()`** — kompletny `SiteDocument` dla fikcyjnej polskiej firmy (nazwa, miasto, pełna oferta z cenami), treści bez fraz z E2, zdjęcia demo z Pexels z atrybucją.
6. **Rejestracja** w `registry.ts`. Szablony dodawane po MVP mają `tier: 'premium'` i `earlyAccessUntil` (Max widzi je 14 dni wcześniej).
7. **Testy** — `SiteDocument.parse(demo())`; kontrast wszystkich presetów; scoring: typowy opis branży daje ten szablon w top 1 (albo uzasadniony wyjątek w PROGRESS).
8. **Ocena wizualna** — zrzuty demo 390 i 1440 px, krytyczna ocena („czy wygląda jak od dobrej agencji?”) i poprawki; Lighthouse ≥ 95.
9. `pnpm catalogs`, potem `pnpm typecheck && pnpm lint && pnpm test`.
